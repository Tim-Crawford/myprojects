/*
 * Project2.c
 *
 * Created: 11/19/2019 8:37:31 PM
 * Authors : Andrew Leise, Tim Crawford, Ben Wandland
 */ 
// Include header files, set CPU frequency
#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#define F_CPU 16000000UL
#include "util/delay.h"

// Function definitions for all functions
void USART_Init(unsigned long BAUDRATE);
char USART_RxChar();
void USART_TxChar(char data);
void USART_TxString(char*);
void Display_Menu(unsigned char selected_mode, char* song);
void Keyboard();
void Note(int bpm, float noteLength, void (*NoteToPlay)(), char* note);
void NoteTimer(int wait);
void NoteTimer256(int wait);
void Rest();
void NoteLowASharp();
void NoteLowB();
void NoteLowC();
void NoteLowD();
void NoteLowDSharp();
void NoteLowE();
void NoteLowF();
void NoteLowFSharp();
void NoteG();
void NoteA();
void NoteASharp();
void NoteB();
void NoteC();
void NoteCSharp();
void NoteD();
void NoteDSharp();
void NoteE();
void NoteF();
void NoteFSharp();
void NoteHighG();
void NoteHighGSharp();
void NoteHighA();
void NoteHighB();
void NoteHighC();
void NoteHighD();
void NoteGSharp();
void NoteHighASharp();
void NoteHighCSharp();
void NoteHighDSharp();
void NoteHighE();
void NoteHighF();
void NoteHighFSharp();
void LEDG();
void LEDA();
void LEDB();
void LEDC();
void LEDD();
void LEDE();
void LEDF();

// Include ISR for USART interface
ISR(USART1_RX_vect);

// USART1 uses PD2 for RxD1 and PD3 for TxD1

unsigned char mode = 0;

int main(void)
{
	// Define all bits except PD2 as output, PD2 as input for serial communication
	DDRD = 0xFB;
	
	// Ensure all LEDs are off, activate PD2's pullup resistor
	PORTD = 0xFF;
	
	// Define speaker and LED5 as output, SW5 as input, then pullup resistors
	DDRE = 0b00110000;
	PORTE = 0b01100000;
	
	// Define switches as input and activate pullup resistors
	DDRA = 0x00;
	PORTA = 0xFF;
	
	// Set up initial timer values and prescalers
	TCCR0A = 0x00;
	TCCR0B = 0b00000101;
	TCCR2A = 0x00;
	TCCR2B = 0b00000111;

	// Initialize USART interface with 9600 baud rate
	USART_Init(9600);
	
	// Enable receiving complete interrupt bit, enable interrupts
	UCSR1B |= (1 << RXCIE);
	sei();
	
	// Display initial menu to serial output
	Display_Menu(0, "");
	
	// Enter infinite while loop
    while (1)
    {
		// If the current mode is song mode, check for switch to play given song
		if(mode == 0)
		{
			//Cave Story Main Theme
			if(~PINA & 0b00000001)
			{
				int bpm = 128; //Note: not actual bpm of song (120bpm)
				Display_Menu(mode, "Cave Story Main Theme");
				
				//Measure 1
				Note(bpm, 0.25, NoteDSharp, "D#, ");
				Note(bpm, 0.25, NoteHighGSharp, "HG#, ");
				Note(bpm, 0.25, NoteDSharp, "D#, ");
				Note(bpm, 0.25, NoteHighGSharp, "HG#, ");
				
				//Measure 2
				Note(bpm, 0.25, NoteD, "D, ");
				Note(bpm, 0.25, NoteHighGSharp, "HG#, ");
				Note(bpm, 0.25, NoteD, "D, ");
				Note(bpm, 0.25, NoteHighGSharp, "HG#, ");
				
				//Measure 3
				Note(bpm, 0.25, NoteCSharp, "C#, ");
				Note(bpm, 0.25, NoteHighGSharp, "HG#, ");
				Note(bpm, 0.25, NoteCSharp, "C#, ");
				Note(bpm, 0.25, NoteHighGSharp, "HG#, ");
				
				//Measure 4
				Note(bpm, 0.25, NoteC, "C, ");
				Note(bpm, 0.25, NoteHighGSharp, "HG#, ");
				Note(bpm, 0.25, NoteC, "C, ");
				Note(bpm, 0.125, NoteCSharp, "C#, ");
				Note(bpm, 0.125, NoteD, "D, ");
			}
			
			//Mimiga Town
			if(~PINA & 0b00000010)
			{
				int bpm = 140; //110 bpm
				Display_Menu(mode, "Mimiga Town");
				
				//Measure 1
				Note(bpm, 0.25, NoteLowF, "LF, ");
				Note(bpm, 0.25, NoteA, "A, ");
				Note(bpm, 0.125, NoteG, "G, ");
				Note(bpm, 0.25, NoteLowF, "LF, ");
				Note(bpm, 0.125, NoteLowF, "LF, ");
				
				//Measure 2
				Note(bpm, 0.25, NoteC, "C, ");
				Note(bpm, 0.125, NoteA, "A, ");
				Note(bpm, 0.375, NoteC, "C, ");
				Note(bpm, 0.25, NoteC, "C, ");
				
				//Measure 3
				Note(bpm, 0.25, NoteD, "D, ");
				Note(bpm, 0.25, NoteC, "C, ");
				Note(bpm, 0.25, NoteF, "F, ");
				Note(bpm, 0.25, NoteC, "C, ");
				
				//Measure 4
				Note(bpm, 0.75, NoteASharp, "A#, ");
			}
			
			//On to Grasstown
			if(~PINA & 0b00000100)
			{
				int bpm = 96; //160 bpm
				Display_Menu(mode, "Grasstown");
				
				//Measure 1
				Note(bpm, 0.0625, NoteG, "G, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.125, NoteLowC, "LC, ");
				Note(bpm, 0.125, Rest, "");
				Note(bpm, 0.125, NoteG, "G, ");
				Note(bpm, 0.0625, NoteA, "A, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.125, NoteG, "G, ");
				Note(bpm, 0.125, Rest, "");
				Note(bpm, 0.125, NoteLowC, "LC, ");
				
				//Measure 2
				Note(bpm, 0.1875, NoteG, "G, ");
				Note(bpm, 0.1875, NoteLowF, "LF, ");
				Note(bpm, 0.125, NoteLowE, "LE, ");
				Note(bpm, 0.125, Rest, "");
				Note(bpm, 0.125, NoteLowE, "LE, ");
				Note(bpm, 0.125, NoteLowD, "LD, ");
				Note(bpm, 0.125, NoteLowE, "LE, ");
				
				//Measure 3
				Note(bpm, 0.375, NoteLowF, "LF, ");
				Note(bpm, 0.0625, NoteLowF, "LF, ");
				Note(bpm, 0.0625, NoteLowE, "LE, ");
				Note(bpm, 0.375, NoteLowD, "LD, ");
				Note(bpm, 0.0625, NoteLowF, "LF, ");
				Note(bpm, 0.0625, NoteLowE, "LE, ");
				
				//Measure 4
				Note(bpm, 1, NoteLowD, "LD, ");
			}
			
			//Meltdown 2
			if(~PINA & 0b00001000)
			{
				int bpm = 110; //140 bpm
				Display_Menu(mode, "Meltdown 2");
				
				//Measure 21
				Note(bpm, 0.1875, NoteHighG, "HG, ");
				Note(bpm, 0.0625, NoteFSharp, "F#, ");
				Note(bpm, 0.1875, NoteHighG, "HG, ");
				Note(bpm, 0.0625, NoteFSharp, "F#, ");
				Note(bpm, 0.125, NoteHighG, "HG, ");
				Note(bpm, 0.0625, NoteE, "E, ");
				Note(bpm, 0.0625, NoteFSharp, "F#, ");
				Note(bpm, 0.125, NoteHighG, "HG, ");
				Note(bpm, 0.125, NoteHighA, "HA, ");
				
				//Measure 22
				Note(bpm, 0.125, NoteHighB, "HB, ");
				Note(bpm, 0.125, NoteHighC, "HC, ");
				Note(bpm, 0.375, NoteHighD, "HD, ");
				Note(bpm, 0.0625, NoteHighC, "HC, ");
				Note(bpm, 0.0625, NoteHighB, "HB, ");
				Note(bpm, 0.125, NoteHighA, "HA, ");
				Note(bpm, 0.125, NoteFSharp, "F#, ");
				
				//Measure 23
				Note(bpm, 0.1875, NoteHighA, "HA, ");
				Note(bpm, 0.0625, NoteHighG, "HG, ");
				Note(bpm, 0.1875, NoteHighA, "HA, ");
				Note(bpm, 0.0625, NoteHighG, "HG, ");
				Note(bpm, 0.125, NoteFSharp, "F#, ");
				Note(bpm, 0.125, NoteE, "E, ");
				Note(bpm, 0.125, NoteD, "D, ");
				Note(bpm, 0.125, NoteE, "E, ");
				
				//Measure 24
				Note(bpm, 0.0625, NoteD, "D, ");
				Note(bpm, 0.0625, NoteE, "E, ");
				Note(bpm, 0.875, NoteD, "D, ");
			}
			
			//Balrog's Theme
			if (~PINE & 0b01000000)
			{
				int bpm = 106; //145 bpm
				Display_Menu(mode, "Balrog's Theme");
				
				//Measure 1
				Note(bpm, 0.0625, NoteLowC, "LC, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowC, "LC, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowFSharp, "LF#, ");
				Note(bpm, 0.1875, Rest, "");
				Note(bpm, 0.0625, NoteLowF, "LF, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowF, "LF, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowFSharp, "LF#, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteG, "G, ");
				Note(bpm, 0.0625, Rest, "");
				
				//Measure 2
				Note(bpm, 0.0625, NoteG, "G, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteG, "G, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowFSharp, "LF#, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowF, "LF, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowDSharp, "LD#, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowDSharp, "LD#, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.1875, NoteLowC, "LC, ");
				Note(bpm, 0.0625, NoteLowB, "LB, ");
				
				//Measure 3
				Note(bpm, 0.0625, NoteLowASharp, "LA#, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowASharp, "LA#, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowF, "LF, ");
				Note(bpm, 0.1875, Rest, "");
				Note(bpm, 0.0625, NoteLowE, "LE, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowE, "LE, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowF, "LF, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowFSharp, "LF#, ");
				Note(bpm, 0.0625, Rest, "");
				
				//Measure 4
				Note(bpm, 0.0625, NoteG, "G, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowFSharp, "LF#, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowF, "LF, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowF, "LF, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowDSharp, "LD#, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.0625, NoteLowDSharp, "LD#, ");
				Note(bpm, 0.0625, Rest, "");
				Note(bpm, 0.125, NoteLowC, "LC, ");
				Note(bpm, 0.0625, Rest, "");
			}
		}
		// If mode is keyboard mode, play specific note for switch
		if(mode == 1)
		{
			if((~PINA & 0x01) && !(~PINA & 0x08) && !(~PINA & 0x10)) //normal
			{
				USART_TxString("G, ");
				while((~PINA & 0x01) && !(~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteG(); //G note
				}
			}
			if((~PINA & 0x01) && (~PINA & 0x08) && !(~PINA & 0x10)) //sharp
			{
				USART_TxString("G#, ");
				while((~PINA & 0x01) && (~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteGSharp();//G# note
				}
			}
			if((~PINA & 0x01) && !(~PINA & 0x08) && (~PINA & 0x10)) //octave
			{
				USART_TxString("HG, ");
				while((~PINA & 0x01) && !(~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighG();//High G note
				}
			}
			if((~PINA & 0x01) && (~PINA & 0x08) && (~PINA & 0x10)) //sharp octave
			{
				USART_TxString("HG#, ");
				while((~PINA & 0x01) && (~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighGSharp();//High G# note
				}
			}
			if((~PINA & 0x02) && !(~PINA & 0x08) && !(~PINA & 0x10)) //normal
			{
				USART_TxString("A, ");
				while((~PINA & 0x02) && !(~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteA();//A note
				}
			}
			if((~PINA & 0x02) && (~PINA & 0x08) && !(~PINA & 0x10)) //sharp
			{
				USART_TxString("A#, ");
				while((~PINA & 0x02) && (~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteASharp();//A# note
				}
			}
			if((~PINA & 0x02) && !(~PINA & 0x08) && (~PINA & 0x10)) //octave
			{
				USART_TxString("HA, ");
				while((~PINA & 0x02) && !(~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighA();//High A note
				}
			}
			if((~PINA & 0x02) && (~PINA & 0x08) && (~PINA & 0x10)) //sharp octave
			{
				USART_TxString("HA#, ");
				while((~PINA & 0x02) && (~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighASharp();//High A# note
				}
			}
			if((~PINA & 0x04) && !(~PINA & 0x08) && !(~PINA & 0x10)) //normal
			{
				USART_TxString("B, ");
				while((~PINA & 0x04) && !(~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteB();//B note
				}
			}
			if((~PINA & 0x04) && (~PINA & 0x08) && !(~PINA & 0x10)) //sharp
			{
				USART_TxString("B, ");
				while((~PINA & 0x04) && (~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteB();//B note
				}
			}
			if((~PINA & 0x04) && !(~PINA & 0x08) && (~PINA & 0x10)) //octave
			{
				USART_TxString("HB, ");
				while((~PINA & 0x04) && !(~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighB();//High B note
				}
			}
			if((~PINA & 0x04) && (~PINA & 0x08) && (~PINA & 0x10)) //sharp octave
			{
				USART_TxString("HB, ");
				while((~PINA & 0x04) && (~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighB();//High B note
				}
			}
			if((~PINE & 0x40) && !(~PINA & 0x08) && !(~PINA & 0x10)) //normal
			{
				USART_TxString("C, ");
				while((~PINE & 0x40) && !(~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteC();//C note
				}
			}
			if((~PINE & 0x40) && (~PINA & 0x08) && !(~PINA & 0x10)) //sharp
			{
				USART_TxString("C#, ");
				while((~PINE & 0x40) && (~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteCSharp();//C# note
				}
			}
			if((~PINE & 0x40) && !(~PINA & 0x08) && (~PINA & 0x10)) //octave
			{
				USART_TxString("HC, ");
				while((~PINE & 0x40) && !(~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighC();//High C note
				}
			}
			if((~PINE & 0x40) && (~PINA & 0x08) && (~PINA & 0x10)) //sharp octave
			{
				USART_TxString("HC#, ");
				while((~PINE & 0x40) && (~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighCSharp();//High C# note
				}
			}			
			if((~PINA & 0x20) && !(~PINA & 0x08) && !(~PINA & 0x10)) //normal
			{
				USART_TxString("D, ");
				while((~PINA & 0x20) && !(~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteD();//D note
				}
			}
			if((~PINA & 0x20) && (~PINA & 0x08) && !(~PINA & 0x10)) //sharp
			{
				USART_TxString("D#, ");
				while((~PINA & 0x20) && (~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteDSharp(); //D# note
				}
			}
			if((~PINA & 0x20) && !(~PINA & 0x08) && (~PINA & 0x10)) //octave
			{
				USART_TxString("HD, ");
				while((~PINA & 0x20) && !(~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighD();//High D note
				}
			}
			if((~PINA & 0x20) && (~PINA & 0x08) && (~PINA & 0x10)) //sharp octave
			{
				USART_TxString("HD#, ");
				while((~PINA & 0x20) && (~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighDSharp();//High D# note
				}
			}
			if((~PINA & 0x40) && !(~PINA & 0x08) && !(~PINA & 0x10)) //normal
			{
				USART_TxString("E, ");
				while((~PINA & 0x40) && !(~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteE();//E note
				}
			}
			if((~PINA & 0x40) && (~PINA & 0x08) && !(~PINA & 0x10)) //sharp
			{
				USART_TxString("E, ");
				while((~PINA & 0x40) && (~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteE();//E note
				}
			}
			if((~PINA & 0x40) && !(~PINA & 0x08) && (~PINA & 0x10)) //octave
			{
				USART_TxString("HE, ");
				while((~PINA & 0x40) && !(~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighE();//High E note
				}
			}
			if((~PINA & 0x40) && (~PINA & 0x08) && (~PINA & 0x10)) //sharp octave
			{
				USART_TxString("HE, ");
				while((~PINA & 0x40) && (~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighE();//High E note
				}
			}
			if((~PINA & 0x80) && !(~PINA & 0x08) && !(~PINA & 0x10)) //normal
			{
				USART_TxString("F, ");
				while((~PINA & 0x80) && !(~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteF();//F note
				}
			}
			if((~PINA & 0x80) && (~PINA & 0x08) && !(~PINA & 0x10)) //sharp
			{
				USART_TxString("F#, ");
				while((~PINA & 0x80) && (~PINA & 0x08) && !(~PINA & 0x10))
				{
					NoteFSharp();//F# note
				}
			}
			if((~PINA & 0x80) && !(~PINA & 0x08) && (~PINA & 0x10)) //octave
			{
				USART_TxString("HF, ");
				while((~PINA & 0x80) && !(~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighF();//High F note
				}
			}
			if((~PINA & 0x80) && (~PINA & 0x08) && (~PINA & 0x10)) //sharp octave
			{
				USART_TxString("HF#, ");
				while((~PINA & 0x80) && (~PINA & 0x08) && (~PINA & 0x10))
				{
					NoteHighFSharp();//High F# note
				}
			}
		}
    }
}

// Function implmemtation for USART_Init
void USART_Init(unsigned long BAUDRATE)
{
	// Calculate baud prescaler value and set low/high bytes of baud rate register
	int BAUD_PRESCALER = (F_CPU / (BAUDRATE * 16UL)) - 1;
	UBRR1L = BAUD_PRESCALER;
	UBRR1H = (BAUD_PRESCALER >> 8);
	
	// Enable transmitter and receiver in status control register B
	UCSR1B |= (1 << RXEN) | (1 << TXEN);
	
	// Set bits corresponding to 8-bit data transfer, one stop bit, asychronous
	UCSR1C |= (1 << UCSZ0) | (1 << UCSZ1);
}

// Function implementation for UART_RxChar
char USART_RxChar()
{
	// Check to see if character has been received
	if(UCSR1A & (1 << RXC))
	{
		// If char is received, return it
		return UDR1;
	}
	else
	{
		// If no char is received, return null
		return '\0';
	}
}

// Function implementation for USART_TxChar
void USART_TxChar(char data)
{
	// Set data to UDR1 register, then loop while data is being transferred
	UDR1 = data;
	while(!(UCSR1A & (1 << UDRE)));
}

// Function implementation for USART_TxString
void USART_TxString(char *str)
{
	// Loop while characters still exist in the string, and transmit each character individually
	while(*str != '\0')
	{
		USART_TxChar(*str++);
	}
}

// Interrupt service routine implementation
ISR(USART1_RX_vect)
{
	// Set character to received value
	unsigned char val = UDR1;
	
	// If a 1 was received, change to mode 0 (if not already in mode 0) and output new menu
	if(val == '1')
	{
		if(mode != 0)
		{
			mode = 0;
			Display_Menu(mode, "");
		}
	}
	// If a 2 was received, change to mode 1 (if not already in mode 1) and output new menu
	else if(val == '2')
	{
		if(mode != 1)
		{
			mode = 1;
			Display_Menu(mode, "");
		}
	}
}

// Function implementation for Display_Menu
void Display_Menu(unsigned char selected_mode, char* song)
{
	// Clear terminal by calling PuTTY specific command
	USART_TxChar(27);
	USART_TxString("[2J");
	USART_TxChar(27);
	USART_TxString("[H");
	
	// Output new menu to the terminal
	USART_TxString("Song selection menu\r\n");
	USART_TxString("Select one of the following modes!\r\n");
	USART_TxString("1 - Song Mode: Play one of the stored songs\r\n");
	USART_TxString("2 - Keyboard Mode: Play your own tunes!\r\n");
	
	// Display the current mode and song based on passed values
	// Song mode
	if (selected_mode == 0)
	{
		// No song is passed
		if (song[0] == '\0')
		{
			USART_TxString("Current Mode = 1\r\n\n");
		}
		// Song is being played
		else
		{
			USART_TxString("Current Mode = 1\r\n\n");
			USART_TxString("Current Song = ");
			USART_TxString(song);
			USART_TxString("\r\n\n");
			USART_TxString("Played Keys:\r\n");
		}
	}
	// Keyboard mode
	else if(selected_mode == 1)
	{
		USART_TxString("Current Mode = 2\r\n\n");
		USART_TxString("Played Keys:\r\n");
	}
}

// Play a specified note for the length of the note
void Note(int bpm, float noteLength, void (*NoteToPlay)(), char* note)
{
	USART_TxString(note);
	for(int i = 0; i < bpm*noteLength; i++)
	{
		TCNT2 = -244;
		while (!(TIFR2 & (1<<TOV2)))
		{
			NoteToPlay();
		}
		TIFR2 = 1<<TOV2;
	}
}

// Timer with 1024 prescaling
void NoteTimer(int wait)
{
	TCNT0 = wait;
	TCCR0A = 0x00;
	TCCR0B = 0b00000101;
	while (!(TIFR0 & (1<<TOV0)));
	PORTE ^= 0b00010000;
	TIFR0 = 1<<TOV0;
}

// Timer with 256 prescaling
void NoteTimer256(int wait)
{
	TCNT0 = wait;
	TCCR0A = 0x00;
	TCCR0B = 0b00000100;
	while (!(TIFR0 & (1<<TOV0)));
	PORTE ^= 0b00010000;
	TIFR0 = 1<<TOV0;
}

// The most important function in the entire project
void Rest(){}

// All of the note functions are after this point
void NoteLowASharp()
{
	LEDA();
	LEDB();
	NoteTimer(-67);
	LEDA();
	LEDB();
}

void NoteLowB()
{
	LEDB();
	NoteTimer256(-253);
	LEDB();
}

void NoteLowC()
{
	LEDC();
	NoteTimer256(-239);
	LEDC();
}

void NoteLowD()
{
	LEDD();
	NoteTimer(-53);
	LEDD();
}

void NoteLowDSharp()
{
	LEDD();
	LEDE();
	NoteTimer256(-201);
	LEDD();
	LEDE();
}

void NoteLowE()
{
	LEDE();
	NoteTimer(-47);
	LEDE();
}

void NoteLowF()
{
	LEDF();
	NoteTimer(-45);
	LEDF();
}

void NoteLowFSharp()
{
	LEDF();
	LEDG();
	NoteTimer256(-169);
	LEDF();
	LEDG();
}

void NoteG()
{
	LEDG();
	NoteTimer(-40);
	LEDG();
}

void NoteA()
{
	LEDA();
	NoteTimer(-35);
	LEDA();
}

void NoteASharp()
{
	LEDA();
	LEDB();
	NoteTimer256(-134);
	LEDA();
	LEDB();
}

void NoteB()
{
	LEDB();
	NoteTimer(-31);
	LEDB();
}

void NoteC()
{
	LEDC();
	NoteTimer(-30);
	LEDC();
}

void NoteCSharp()
{
	LEDC();
	LEDD();
	NoteTimer(-28);
	LEDC();
	LEDD();
}

void NoteD()
{
	LEDD();
	NoteTimer(-26);
	LEDD();
}

void NoteDSharp()
{
	LEDD();
	LEDE();
	NoteTimer(-25);
	LEDD();
	LEDE();
}

void NoteE()
{
	LEDE();
	NoteTimer(-24);
	LEDE();
}

void NoteF()
{
	LEDF();
	NoteTimer256(-89);
	LEDF();
}

void NoteFSharp()
{
	LEDF();
	LEDG();
	NoteTimer(-21);
	LEDF();
	LEDG();
}

void NoteHighG()
{
	LEDG();
	NoteTimer256(-80);
	LEDG();
}

void NoteHighGSharp()
{
	LEDG();
	LEDA();
	NoteTimer256(-75);
	LEDG();
	LEDA();
}

void NoteHighA()
{
	LEDA();
	NoteTimer256(-71);
	LEDA();
}

void NoteHighB()
{
	LEDB();
	NoteTimer256(-63);
	LEDB();
}

void NoteHighC()
{
	LEDC();
	NoteTimer256(-60);
	LEDC();
}

void NoteHighD()
{
	LEDD();
	NoteTimer256(-53);
	LEDD();
}

void NoteGSharp(){
	LEDG();
	LEDA();
	NoteTimer(-19);
	LEDG();
	LEDA();
}

void NoteHighASharp(){
	LEDA();
	LEDB();
	NoteTimer(-17);
	LEDA();
	LEDB();
}

void NoteHighCSharp(){
	LEDC();
	LEDD();
	NoteTimer(-14);
	LEDC();
	LEDD();
}

void NoteHighDSharp(){
	LEDD();
	LEDE();
	NoteTimer(-13);
	LEDD();
	LEDE();
}
void NoteHighE(){
	LEDE();
	NoteTimer(-12);
	LEDE();
}

void NoteHighF(){
	LEDF();
	LEDG();
	NoteTimer(-11);
	LEDF();
	LEDG();
}

void NoteHighFSharp(){
	LEDF();
	LEDG();
	NoteTimer(-10);
	LEDF();
	LEDG();
}


//LEDs for each note
void LEDG()
{
	PORTD ^= 0b00000001;
}

void LEDA()
{
	PORTD ^= 0b00000010;
}

void LEDB()
{
	PORTD ^= 0b00010000;
}

void LEDC()
{
	PORTE ^= 0b00100000;
}

void LEDD()
{
	PORTD ^= 0b00100000;
}

void LEDE()
{
	PORTD ^= 0b01000000;
}

void LEDF()
{
	PORTD ^= 0b10000000;
}
